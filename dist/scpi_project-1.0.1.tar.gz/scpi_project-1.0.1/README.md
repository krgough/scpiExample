# scpiProject

This project contains modules that send scpi commands to instruments e.g. 34465a multimeter, to set up measuremnts and log the data.

34465a Module contains specific code to send test commands to tha device.  It included a current consumption test method we can use to
log current consumption in devices over extended periods.  See the device manual for detials of the commands.
